import { Router } from "express";
import { Item } from "../models/Item.js";
import mongoose from "mongoose";

const router = Router();

/**
 * GET /items
 * Optional query params:
 *  - q (text search in title/description)
 *  - minPrice, maxPrice
 *  - active (true/false)
 *  - limit, page
 */
router.get("/", async (req, res, next) => {
  try {
    const {
      q,
      minPrice,
      maxPrice,
      active,
      limit = 20,
      page = 1
    } = req.query;

    const filter = {};

    if (q) {
      filter.$or = [
        { title: { $regex: q, $options: "i" } },
        { description: { $regex: q, $options: "i" } }
      ];
    }
    if (active !== undefined) {
      filter.active = active === "true";
    }
    if (minPrice || maxPrice) {
      filter.price = {};
      if (minPrice) filter.price.$gte = Number(minPrice);
      if (maxPrice) filter.price.$lte = Number(maxPrice);
    }

    const lim = Math.min(Number(limit) || 20, 100);
    const skip = (Number(page) - 1) * lim;

    const [items, total] = await Promise.all([
      Item.find(filter).sort({ createdAt: -1 }).skip(skip).limit(lim),
      Item.countDocuments(filter)
    ]);

    res.json({
      data: items,
      meta: { total, page: Number(page), limit: lim, pages: Math.ceil(total / lim) }
    });
  } catch (err) {
    next(err);
  }
});

/**
 * GET /items/:id
 */
router.get("/:id", async (req, res, next) => {
  try {
    const { id } = req.params;
    if (!mongoose.isValidObjectId(id)) return res.status(400).json({ error: "invalid id" });
    const item = await Item.findById(id);
    if (!item) return res.status(404).json({ error: "not found" });
    res.json(item);
  } catch (err) {
    next(err);
  }
});

/**
 * POST /items
 * body: { title (req), description?, price?, tags?, active? }
 */
router.post("/", async (req, res, next) => {
  try {
    const item = await Item.create(req.body);
    res.status(201).json(item);
  } catch (err) {
    next(err);
  }
});

/**
 * PUT /items/:id  (replace all provided fields)
 * PATCH /items/:id (partial update)
 */
async function updateHandler(req, res, next, opts) {
  try {
    const { id } = req.params;
    if (!mongoose.isValidObjectId(id)) return res.status(400).json({ error: "invalid id" });

    const item = await Item.findByIdAndUpdate(id, req.body, {
      new: true,           // return updated doc
      runValidators: true, // enforce schema validators
      overwrite: opts.overwrite ?? false
    });

    if (!item) return res.status(404).json({ error: "not found" });
    res.json(item);
  } catch (err) {
    next(err);
  }
}

router.put("/:id", (req, res, next) => updateHandler(req, res, next, { overwrite: true }));
router.patch("/:id", (req, res, next) => updateHandler(req, res, next, { overwrite: false }));

/**
 * (Optional) DELETE /items/:id
 */
router.delete("/:id", async (req, res, next) => {
  try {
    const { id } = req.params;
    if (!mongoose.isValidObjectId(id)) return res.status(400).json({ error: "invalid id" });
    const item = await Item.findByIdAndDelete(id);
    if (!item) return res.status(404).json({ error: "not found" });
    res.json({ ok: true });
  } catch (err) {
    next(err);
  }
});

export default router;
